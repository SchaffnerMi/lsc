Different samples are available in the sub-directories : 

- ad : two samples configuration for synchronizing from and to an Active Directory 
- asyncldap : a sample synchronizing accounts on the fly from OpenLDAP to OpenDJ
- hsqldb : a sample synchronizing accounts from HsqlDB to OpenDJ 
- nis : a sample synchronizing accounts from NIS to OpenLDAP  (nis plugin required)
- postgresql : a sample synchronizing accounts from OpenDJ to PostgreSQL
- ldap2hsqldb : a sample synchronizing accounts from OpenDJ to HsqlDB
