INSERT INTO public.inetorgperson VALUES ( 'jsmith-test', 'Smith', 'Jane', 'Smith, Jane', 'jsmith@foobar.com', 'The White House, Washington DC, United States', '(1) 123 45679', 2);
