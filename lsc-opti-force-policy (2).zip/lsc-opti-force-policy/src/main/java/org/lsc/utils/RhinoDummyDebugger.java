package org.lsc.utils;


public class RhinoDummyDebugger {
    public void show() {
        // Do nothing 
    }
}
